SELECT * FROM city_data WHERE city = 'Kano' AND country = 'Nigeria';

SELECT * FROM global_data;